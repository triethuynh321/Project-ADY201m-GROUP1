# Daily run — Phase A (Ubuntu 22.04 / Humble / Harmonic / PX4 v1.17)

Three terminals. Source env in each:

```bash
export DRONE_ROOT="$HOME/Workspace/260727-drone-setup"
source "$DRONE_ROOT/env.sh"
```

## Terminal 1 — Micro XRCE-DDS Agent

```bash
export LD_LIBRARY_PATH="$DRONE_ROOT/xrce-agent-install/lib:${LD_LIBRARY_PATH:-}"
"$XRCE_AGENT" udp4 -p 8888
```

## Terminal 2 — PX4 SITL + Gazebo

GUI (default model/world from `env.sh`: `gz_x500_mono_cam` + `baylands`):

```bash
cd "$PX4_DIR"
source "$PX4_VENV/bin/activate"
make px4_sitl "$PX4_SIM_MODEL"
```

`baylands` downloads Fuel models on first run (~150 MB+). If PX4 prints `Timed out waiting for Gazebo world`, either wait for the download to finish and restart PX4, or use a local world:

```bash
PX4_GZ_WORLD=default make px4_sitl "$PX4_SIM_MODEL"
```

Or headless smoke test (`gz_x500` + `default`):

```bash
cd "$PX4_DIR/build/px4_sitl_default/rootfs"
source ./gz_env.sh
HEADLESS=1 PX4_SIM_MODEL=gz_x500 PX4_GZ_WORLD=default GZ_IP=127.0.0.1 ../bin/px4
```

Wait until the PX4 console shows the `pxh>` prompt and the vehicle is ready (no continuous EKF / home-position errors).

## Fly the drone (takeoff / land / modes)

### Option A — PX4 shell (same Terminal 2)

Type commands at the `pxh>` prompt:

```text
commander takeoff          # arm + takeoff (Hold / Takeoff mode)
commander land             # land at current position
commander arm              # arm only (motors spin; no takeoff)
commander disarm           # disarm (use commander disarm -f if needed)
commander mode posctl      # Position mode
commander mode altctl      # Altitude mode
commander mode manual      # Manual mode
commander mode auto:loiter # Loiter / Hold
commander check            # preflight check status
```

If you see `Arming denied: Resolve system health failures first`, PX4 needs a **GCS datalink** (`NAV_DLL_ACT=2` on this airframe). Either:

- Start **QGroundControl** (Option B) so it connects, then retry `commander takeoff`, **or**
- Disable the requirement for this SITL session:

```text
param set NAV_DLL_ACT 0
commander takeoff
```

Typical short flight:

```text
commander takeoff
# wait until airborne and stable
commander land
```

Emergency stop (kills actuators immediately):

```text
commander disarm -f
```

### Option B — QGroundControl

1. Install [QGroundControl](https://docs.qgroundcontrol.com/master/en/qgc-user-guide/getting_started/download_and_install.html) (AppImage is fine on Ubuntu 22.04).
2. Start QGC **after** PX4 SITL is running. It usually auto-connects over UDP.
3. If it does not connect: **Application Settings → Comm Links → Add** → UDP, listening port **18570** (PX4 SITL GCS port for instance 0), then Connect.
4. In the Fly view: set mode (e.g. Hold / Position), arm, **Takeoff**, then **Land** / **RTL** when done.

Virtual joystick (optional): **Application Settings → General → Virtual Joystick**.

Connecting QGC also clears the “no GCS” arming block used by Option A.

### Option C — Scripted 30s circuit

With SITL already running:

```bash
source "$DRONE_ROOT/.venv/bin/activate"
python "$DRONE_ROOT/fly_around_30s.py" --duration 30 --alt 5 --radius 6 --pattern square
# or: --pattern circle
deactivate
```

If arming is denied: at `pxh>` run `param set NAV_DLL_ACT 0` (or connect QGC).

## Terminal 3 — ROS 2 checks

```bash
ros2 topic list | grep fmu
ros2 topic echo /fmu/out/sensor_combined --once
```

## Phase B — Camera bridge + YOLO

Requires Phase A running with **`gz_x500_mono_cam`** (camera airframe). First-time setup (once):

```bash
# Already created on this machine if present:
#   $DRONE_ROOT/.venv_cv   (ultralytics + torch; CUDA build preferred)
#   $DRONE_ROOT/ws_cv      (drone_cv package)
source /opt/ros/humble/setup.bash
cd "$DRONE_ROOT/ws_cv"
colcon build --symlink-install --packages-select drone_cv
```

Discover the Gazebo camera topic (if you changed world/model):

```bash
gz topic -l | grep -iE 'image$'
# then override, e.g.:
# export DRONE_CAMERA_GZ_TOPIC='/world/<world>/model/<model>/link/camera_link/sensor/imager/image'
```

### Terminal 4 — bridge + YOLO + view

```bash
export DRONE_ROOT="$HOME/Workspace/260727-drone-setup"
source "$DRONE_ROOT/env.sh"
# Do NOT activate $PX4_VENV here

ros2 launch drone_cv detect.launch.py
```

Defaults (`env.sh`):

| Variable | Default |
|----------|---------|
| `DRONE_CAMERA_GZ_TOPIC` | `/world/baylands/model/x500_mono_cam_0/link/camera_link/sensor/imager/image` |
| `DRONE_CAMERA_ROS_TOPIC` | `/drone/camera/image_raw` |
| `YOLO_WEIGHTS` | `$DRONE_ROOT/ws_cv/yolov8n.pt` |
| `YOLO_DEVICE` | `cpu` (use `cuda:0` after installing CUDA torch — see below) |

Optional overrides:

```bash
YOLO_DEVICE=cuda:0 ros2 launch drone_cv detect.launch.py view:=true
# headless (no rqt window):
ros2 launch drone_cv detect.launch.py view:=false
```

If `YOLO_DEVICE=cuda:0` crashes with `torch.cuda.is_available(): False`, the venv still has the CPU wheel. Install a CUDA build once:

```bash
source "$DRONE_ROOT/.venv_cv/bin/activate"
pip install --upgrade torch torchvision --index-url https://download.pytorch.org/whl/cu126
pip install 'numpy==1.26.4'
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
deactivate
```

### Animated objects (person / SUV / ambulance)

PX4 + Gazebo must already be running (`gz_x500_mono_cam`). Props spawn in Gazebo, **animate** (sway / orbit), and **follow the drone** so they stay in the camera view for YOLO.

**Props only** (recommended if YOLO is already running, or you only want objects):

```bash
export DRONE_ROOT="$HOME/Workspace/260727-drone-setup"
source "$DRONE_ROOT/env.sh"
ros2 run drone_cv yolo_props
```

Do not type a leading `~` before `export`.

Expect log lines like `Spawned yolo_person` / `Props ready`. Objects stay **on the ground ahead of the drone** (not on top of it) and animate while following. Leave this terminal open — animation stops if you Ctrl+C.

If the drone looks stuck under a car, Ctrl+C props, restart `yolo_props` (it removes stale `yolo_*` models), then fly again.

**Props + YOLO together** (`props:=true` is the default):

```bash
source "$DRONE_ROOT/env.sh"
ros2 launch drone_cv detect.launch.py props:=true
```

Disable props: `ros2 launch drone_cv detect.launch.py props:=false`.

If the world/model name differs from defaults:

```bash
ros2 run drone_cv yolo_props --ros-args \
  -p world:=baylands \
  -p drone_model:=x500_mono_cam_0
```

First run may download Fuel models (Standing person / SUV / Ambulance) into `~/.gz/fuel/`.

### See results

1. **Annotated image window** — `rqt_image_view` on `/yolo_detect/image_annotated` (`view:=true`).
   If you still see a blank gradient, the old `yolo_detect` crashed or was publishing the wrong topic — restart:

```bash
# Ctrl+C the previous detect.launch, then:
source "$DRONE_ROOT/env.sh"
ros2 launch drone_cv detect.launch.py
```

   Sanity check: `ros2 topic hz /yolo_detect/image_annotated` should show a rate, and `ros2 node info /yolo_detect` should list publisher `/yolo_detect/image_annotated`.
2. **Raw camera** (optional extra terminal):

```bash
ros2 run rqt_image_view rqt_image_view /drone/camera/image_raw
```

3. **Detection messages**:

```bash
ros2 topic echo /yolo_detect/detections --once
ros2 topic hz /yolo_detect/detections
```

4. **Confirm bridge is feeding images**:

```bash
ros2 topic hz /drone/camera/image_raw
```

Take off and point the drone at people/cars/objects in the world — COCO-pretrained `yolov8n` labels appear in the annotated view and on `/yolo_detect/detections`.

Bridge only (no YOLO):

```bash
ros2 launch drone_cv camera_bridge.launch.py
```

### Multi-drone (add extras + YOLO / stress test)

With Phase A already running (instance **0** = `x500_mono_cam_0`), spawn extras and fly them.

**Stress test — 7 extra drones** (default):

```bash
export DRONE_ROOT="$HOME/Workspace/260727-drone-setup"
source "$DRONE_ROOT/env.sh"

# Stop previous extras, respawn lightweight gz_x500 (no camera)
"$DRONE_ROOT/spawn_extra_drones.sh" --stop
"$DRONE_ROOT/spawn_extra_drones.sh"            # 7 x gz_x500 (recommended)
# more: "$DRONE_ROOT/spawn_extra_drones.sh" --count 15
# cameras (slow): "$DRONE_ROOT/spawn_extra_drones.sh" --camera

# Wait until real_time_factor recovers (aim >0.5)
# gz topic -e -t /stats -n 1 | grep real_time_factor

source "$DRONE_ROOT/.venv/bin/activate"
python "$DRONE_ROOT/fly_extra_drones.py"       # staggered alts, onboard MAVLink
deactivate
```

Extras sit on a 5×N grid (6 m spacing). Flight uses **onboard** ports `14580+N` (OFFBOARD). Default spawn is **without cameras** — many `mono_cam` vehicles often drop Gazebo to ~0.1× real-time and then EKF/arming fails.

**YOLO on many cameras** is much heavier than flight-only stress. Prefer a small subset:

```bash
# stop single-drone detect.launch first if running
ros2 launch drone_cv multi_detect.launch.py instances:=0,1,2 view:=false
```

Stop extras:

```bash
"$DRONE_ROOT/spawn_extra_drones.sh" --stop
```

Per-drone camera topics (`N` = instance id):

| Kind | Topic |
|------|--------|
| Raw camera | `/drone_N/camera/image_raw` |
| Annotated | `/drone_N/yolo_detect/image_annotated` |
| Detections | `/drone_N/yolo_detect/detections` |

## One-shot integration test

```bash
bash "$DRONE_ROOT/run_integration_test.sh"
```

Expect `PASS: Phase A integration test OK`.

## Notes

- Start the agent **before** PX4.
- Keep `RMW_IMPLEMENTATION=rmw_fastrtps_cpp` (set by `env.sh`).
- Do not activate `$PX4_VENV` when running `colcon` / ROS / YOLO tools.
- YOLO loads packages from `$CV_VENV` (`.venv_cv`); keep ROS on system Python 3.10.
- If the annotated view is black: check `gz topic -l | grep image` and that `DRONE_CAMERA_GZ_TOPIC` matches your world/model.
