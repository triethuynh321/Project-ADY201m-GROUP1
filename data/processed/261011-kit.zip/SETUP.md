# Setup guide — another Ubuntu 22.04 machine

Reproduce the **Phase A** flight stack on a clean **Ubuntu 22.04 LTS (Jammy)** Desktop VM/host.

**Do not** follow Noble/Jazzy instructions on this OS. Use this stack only:

| Component | Version |
|-----------|---------|
| OS | Ubuntu **22.04** (Jammy) |
| ROS 2 | **Humble** |
| Gazebo | **Harmonic** 8.x (`gz-harmonic`) |
| ros_gz | **`ros-humble-ros-gzharmonic`** (from OSRF repo, not Fortress `ros-humble-ros-gz`) |
| PX4 | **v1.17.0** |
| px4_msgs | **release/1.17** |
| Micro XRCE-DDS Agent | **v2.4.3** |
| RMW | **rmw_fastrtps_cpp** |

After setup, run the stack with **[RUN.md](RUN.md)**.

---

## 0. Machine requirements

| Item | Recommended | Absolute minimum |
|------|-------------|------------------|
| RAM | 16 GB | 8 GB (use `gz_x500` + `default`, headless) |
| Disk free | 80 GB+ | ~40 GB before installs |
| CPU | 4+ cores | 2 cores (slow builds) |
| 3D | VMware 3D acceleration on | Needed for Gazebo GUI |

```bash
lsb_release -a    # must show 22.04
df -h /
free -h
nproc
```

**Abort if** not 22.04, or free disk is far below ~40 GB.

Choose a workspace root (this tree uses `260727-drone-setup`):

```bash
export DRONE_ROOT="$HOME/Workspace/260727-drone-setup"
mkdir -p "$DRONE_ROOT" "$HOME/workspace"
ln -sfn "$DRONE_ROOT" "$HOME/workspace/drone-setup"
cd "$DRONE_ROOT"
```

Optional: put `export DRONE_ROOT=...` in `~/.bashrc`.

---

## 1. Base packages

```bash
sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install -y curl wget git build-essential cmake ninja-build \
  python3-pip python3-venv python3-opencv v4l-utils \
  software-properties-common locales lsb-release gnupg
```

**Do not** add the ROS 1 apt repo (`packages.ros.org/ros/ubuntu`) — it breaks `apt` on modern Ubuntu.

`python3-colcon-common-extensions` comes with the ROS 2 apt repo (next section).

---

## 2. ROS 2 Humble

```bash
sudo add-apt-repository universe -y
sudo apt-get update

sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
  -o /usr/share/keyrings/ros-archive-keyring.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" | \
  sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

sudo apt-get update
sudo apt-get install -y ros-humble-desktop ros-dev-tools \
  ros-humble-vision-msgs ros-humble-cv-bridge ros-humble-image-transport \
  ros-humble-rqt-image-view python3-colcon-common-extensions
```

**Do not** install `ros-humble-ros-gz` yet (that is Fortress). Harmonic bridge is installed in §3 from the OSRF repo.

Verify:

```bash
source /opt/ros/humble/setup.bash
ros2 pkg list | grep -E 'cv_bridge|vision_msgs'
```

Optional:

```bash
grep -q 'source /opt/ros/humble/setup.bash' ~/.bashrc || \
  echo 'source /opt/ros/humble/setup.bash' >> ~/.bashrc
```

---

## 3. Gazebo Harmonic + ros_gzharmonic

Packages come from **packages.osrfoundation.org** (use `https`):

```bash
sudo curl -fsSL https://packages.osrfoundation.org/gazebo.gpg \
  -o /usr/share/keyrings/pkgs-osrf-archive-keyring.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/pkgs-osrf-archive-keyring.gpg] https://packages.osrfoundation.org/gazebo/ubuntu-stable $(lsb_release -cs) main" | \
  sudo tee /etc/apt/sources.list.d/gazebo-stable.list > /dev/null

sudo apt-get update
sudo apt-get install -y gz-harmonic ros-humble-ros-gzharmonic
```

`ros-humble-ros-gzharmonic` conflicts with `ros-humble-ros-gz` (Fortress). Prefer Harmonic only.

Verify:

```bash
/usr/bin/gz sim --versions    # Expect 8.x
pkg-config --modversion gz-sim8
pkg-config --modversion gz-transport13

source /opt/ros/humble/setup.bash
ros2 pkg list | grep ros_gz
```

---

## 4. PX4 Autopilot v1.17.0

**Install Gazebo before the final PX4 build** so CMake finds `gz-transport` and links `gz_bridge`. If you built PX4 earlier without Gazebo, delete the build cache and rebuild (§4.3).

### 4.1 Clone

```bash
cd "$DRONE_ROOT"
git clone --recursive -b v1.17.0 https://github.com/PX4/PX4-Autopilot.git
cd PX4-Autopilot
bash ./Tools/setup/ubuntu.sh --no-nuttx --no-sim-tools
```

(`--no-sim-tools` skips classic/other sim tooling; Harmonic is already installed.)

### 4.2 Python venv (PEP 668 safe)

```bash
cd "$DRONE_ROOT"
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r "$DRONE_ROOT/PX4-Autopilot/Tools/setup/requirements.txt"
deactivate
```

### 4.3 Build SITL (with Gazebo already installed)

```bash
source "$DRONE_ROOT/.venv/bin/activate"
cd "$DRONE_ROOT/PX4-Autopilot"
# On 2-core / 8 GB machines keep parallelism low:
export MAKEFLAGS="-j$(nproc)"
make px4_sitl
deactivate
```

If Gazebo was installed **after** a previous build:

```bash
rm -f "$DRONE_ROOT/PX4-Autopilot/build/px4_sitl_default/CMakeCache.txt"
source "$DRONE_ROOT/.venv/bin/activate"
cd "$DRONE_ROOT/PX4-Autopilot"
make px4_sitl
deactivate
```

Verify:

```bash
cd "$DRONE_ROOT/PX4-Autopilot"
test -x build/px4_sitl_default/bin/px4
test -f build/px4_sitl_default/bin/px4-alias.sh
test -f build/px4_sitl_default/rootfs/gz_env.sh
grep -q 'Found gz-transport\|gz-transport13' build/px4_sitl_default/CMakeCache.txt \
  || grep gz-transport_DIR build/px4_sitl_default/CMakeCache.txt
ninja -C build/px4_sitl_default -t targets | grep -E '^gz_x500_mono_cam$'
ls Tools/simulation/gz/models/x500_mono_cam
ls Tools/simulation/gz/worlds/baylands.sdf
ls ROMFS/px4fmu_common/init.d-posix/airframes/4010_gz_x500_mono_cam
```

Confirm cmake found Gazebo:

```bash
grep 'gz-transport_DIR:PATH=' build/px4_sitl_default/CMakeCache.txt
# Must NOT be gz-transport_DIR-NOTFOUND
```

**Never delete** `bin/px4-*` or `px4-alias.sh`.

---

## 5. Micro XRCE-DDS Agent v2.4.3

```bash
cd "$DRONE_ROOT"
git clone -b v2.4.3 --depth 1 https://github.com/eProsima/Micro-XRCE-DDS-Agent.git
cd Micro-XRCE-DDS-Agent
mkdir -p build && cd build
cmake .. -DCMAKE_INSTALL_PREFIX="$DRONE_ROOT/xrce-agent-install" -DUAGENT_BUILD_EXECUTABLE=ON
make -j"$(nproc)"
make install

export LD_LIBRARY_PATH="$DRONE_ROOT/xrce-agent-install/lib:${LD_LIBRARY_PATH:-}"
"$DRONE_ROOT/xrce-agent-install/bin/MicroXRCEAgent" --help | head
```

PX4 SITL default agent port: **UDP 8888**.

---

## 6. ROS 2 workspace — `ws_px4` / px4_msgs

```bash
mkdir -p "$DRONE_ROOT/ws_px4/src"
cd "$DRONE_ROOT/ws_px4/src"
git clone -b release/1.17 --depth 1 https://github.com/PX4/px4_msgs.git

source /opt/ros/humble/setup.bash
# Keep PX4 .venv off PATH during colcon (breaks catkin_pkg)
export PATH="$(echo "$PATH" | tr ':' '\n' | grep -v "$DRONE_ROOT/.venv" | paste -sd:)"

cd "$DRONE_ROOT/ws_px4"
colcon build --packages-select px4_msgs
source install/setup.bash
ros2 interface package px4_msgs | head
```

---

## 7. `env.sh`

```bash
cat > "$DRONE_ROOT/env.sh" <<'EOF'
#!/usr/bin/env bash
# source "$HOME/Workspace/260727-drone-setup/env.sh"
# Ubuntu 22.04: ROS 2 Humble + Gazebo Harmonic + PX4 v1.17

ROOT="${DRONE_ROOT:-$HOME/Workspace/260727-drone-setup}"

set +u
source /opt/ros/humble/setup.bash
[[ -f "$ROOT/ws_px4/install/setup.bash" ]] && source "$ROOT/ws_px4/install/setup.bash" || true
[[ -f "$ROOT/ws_cv/install/setup.bash" ]] && source "$ROOT/ws_cv/install/setup.bash" || true
set +u

export PKG_CONFIG_PATH="$(find /opt/ros/humble/opt -type d -name pkgconfig 2>/dev/null | paste -sd:):${PKG_CONFIG_PATH:-}"
_GZ_LIBS="$(find /opt/ros/humble/opt -type d \( -name lib -o -name lib64 \) 2>/dev/null | paste -sd:)"
export LD_LIBRARY_PATH="${_GZ_LIBS}:${ROOT}/xrce-agent-install/lib:${LD_LIBRARY_PATH:-}"
export PATH="/usr/bin:/opt/ros/humble/opt/gz_tools_vendor/bin:${ROOT}/xrce-agent-install/bin:${PATH}"

export PX4_VENV="$ROOT/.venv"
export PX4_DIR="$ROOT/PX4-Autopilot"
export XRCE_AGENT="$ROOT/xrce-agent-install/bin/MicroXRCEAgent"
export CV_VENV="$ROOT/.venv_cv"
export GZ_VERSION=harmonic
export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-0}"
export RMW_IMPLEMENTATION="${RMW_IMPLEMENTATION:-rmw_fastrtps_cpp}"

export PX4_SIM_MODEL="${PX4_SIM_MODEL:-gz_x500_mono_cam}"
export PX4_GZ_WORLD="${PX4_GZ_WORLD:-baylands}"
export GZ_IP="${GZ_IP:-127.0.0.1}"

export DRONE_CAMERA_GZ_TOPIC="${DRONE_CAMERA_GZ_TOPIC:-}"
export DRONE_CAMERA_ROS_TOPIC="${DRONE_CAMERA_ROS_TOPIC:-/drone/camera/image_raw}"
export YOLO_WEIGHTS="${YOLO_WEIGHTS:-yolov8n.pt}"
export YOLO_DEVICE="${YOLO_DEVICE:-cpu}"

echo "drone-setup env ready (Ubuntu 22.04 / Humble):"
echo "  ros:     humble | rmw=$RMW_IMPLEMENTATION"
echo "  gz:      $(gz sim --versions 2>/dev/null | head -1)"
echo "  model:   $PX4_SIM_MODEL | world=$PX4_GZ_WORLD"
echo "  px4_dir: $PX4_DIR"
echo "  agent:   $XRCE_AGENT"
echo "  cv_venv: $CV_VENV"
echo "  cam_ros: $DRONE_CAMERA_ROS_TOPIC | yolo=$YOLO_WEIGHTS ($YOLO_DEVICE)"
EOF
chmod +x "$DRONE_ROOT/env.sh"
```

If your path is not `$HOME/Workspace/260727-drone-setup`, edit the default `ROOT=` line.

---

## 8. Integration test script

```bash
cat > "$DRONE_ROOT/run_integration_test.sh" <<'EOF'
#!/usr/bin/env bash
# Phase A: XRCE + headless PX4 SITL + /fmu/out/sensor_combined
set -uo pipefail

ROOT="${DRONE_ROOT:-$HOME/Workspace/260727-drone-setup}"
# shellcheck disable=SC1091
source "$ROOT/env.sh"

kill_stale() {
  local p
  for p in gz px4 MicroXRCEAgent; do
    pidof "$p" 2>/dev/null | xargs -r kill -9 || true
  done
}

cleanup() {
  set +e
  [[ -n "${PX4_PID:-}" ]] && kill "$PX4_PID" 2>/dev/null
  [[ -n "${AGENT_PID:-}" ]] && kill "$AGENT_PID" 2>/dev/null
  kill_stale
}
trap cleanup EXIT

kill_stale
sleep 1

echo "[1/4] Starting MicroXRCEAgent udp4 -p 8888"
export LD_LIBRARY_PATH="$ROOT/xrce-agent-install/lib:${LD_LIBRARY_PATH:-}"
"$XRCE_AGENT" udp4 -p 8888 > /tmp/xrce_agent.log 2>&1 &
AGENT_PID=$!
sleep 2
if ! kill -0 "$AGENT_PID" 2>/dev/null; then
  echo "FAIL: MicroXRCEAgent did not start"
  cat /tmp/xrce_agent.log || true
  exit 1
fi

echo "[2/4] Starting PX4 SITL (headless, gz_x500 + default)"
mkdir -p "$PX4_DIR/build/px4_sitl_default/rootfs"
cd "$PX4_DIR/build/px4_sitl_default/rootfs"
# shellcheck disable=SC1091
source ./gz_env.sh

MODEL="${PX4_SIM_MODEL_TEST:-gz_x500}"
WORLD="${PX4_GZ_WORLD_TEST:-default}"
HEADLESS=1 PX4_SIM_MODEL="$MODEL" PX4_GZ_WORLD="$WORLD" GZ_IP="${GZ_IP:-127.0.0.1}" \
  ../bin/px4 -d > /tmp/px4_sitl.log 2>&1 &
PX4_PID=$!
sleep 5
if ! kill -0 "$PX4_PID" 2>/dev/null; then
  echo "FAIL: px4 did not stay running"
  tail -80 /tmp/px4_sitl.log || true
  exit 1
fi

echo "[3/4] Waiting for /fmu topics (up to 180s)..."
OK=0
for i in $(seq 1 90); do
  if ros2 topic list 2>/dev/null | grep -q '/fmu/out/sensor_combined'; then
    OK=1
    break
  fi
  if ! kill -0 "$PX4_PID" 2>/dev/null; then
    echo "FAIL: px4 exited while waiting for topics"
    tail -100 /tmp/px4_sitl.log || true
    exit 1
  fi
  sleep 2
done

if [[ "$OK" -ne 1 ]]; then
  echo "FAIL: /fmu/out/sensor_combined not found"
  ros2 topic list 2>/dev/null | grep fmu || true
  tail -100 /tmp/px4_sitl.log || true
  tail -50 /tmp/xrce_agent.log || true
  exit 1
fi

echo "[4/4] Echoing /fmu/out/sensor_combined once"
timeout 30 ros2 topic echo /fmu/out/sensor_combined --once
echo "PASS: Phase A integration test OK"
EOF
chmod +x "$DRONE_ROOT/run_integration_test.sh"
```

Run:

```bash
bash "$DRONE_ROOT/run_integration_test.sh"
```

**Phase A done when** you see `PASS` and a `sensor_combined` message.

---

## 9. Checklist

- [ ] Ubuntu 22.04, enough disk/RAM
- [ ] ROS Humble + vision packages
- [ ] Gazebo Harmonic 8.x + `ros-humble-ros-gzharmonic`
- [ ] PX4 v1.17.0 built **after** Gazebo; `gz_env.sh` present; `gz-transport` found
- [ ] MicroXRCEAgent on UDP 8888
- [ ] `px4_msgs` release/1.17 built
- [ ] `env.sh` works
- [ ] Integration test: `/fmu/out/sensor_combined` OK

Then use **[RUN.md](RUN.md)** for the daily 3-terminal workflow.

---

## 10. Pitfalls (learned on bring-up)

| Symptom | Fix |
|---------|-----|
| `Unable to locate package ros-humble-ros-gzharmonic` | Add OSRF Gazebo apt repo (`https://packages.osrfoundation.org/...`) then `apt update` |
| Installed `ros-humble-ros-gz` by mistake | Remove it; install `ros-humble-ros-gzharmonic` |
| PX4 runs but no Gazebo / no `gz_bridge` | Rebuild PX4 after installing `gz-harmonic` (`rm CMakeCache.txt` + `make px4_sitl`) |
| `colcon` / `catkin_pkg` errors | Remove `$DRONE_ROOT/.venv` from `PATH` |
| No `/fmu` topics | Start agent first; `RMW_IMPLEMENTATION=rmw_fastrtps_cpp` |
| OOM / very slow | `-j2`, headless, `gz_x500` + `default`; add RAM |
| `libGstCameraSystem.so` missing | Camera GStreamer plugin not built — fix before Phase B camera stream |

---

## 11. Final layout

```text
$DRONE_ROOT/
├── SETUP.md                 # this file
├── RUN.md                   # how to run day-to-day (Phase A + B)
├── AGENT_SETUP.md           # short version pin summary
├── env.sh
├── run_integration_test.sh
├── .venv/                   # PX4 build Python only
├── .venv_cv/                # Ultralytics YOLO (Phase B)
├── PX4-Autopilot/           # v1.17.0
├── Micro-XRCE-DDS-Agent/
├── xrce-agent-install/
├── ws_px4/                  # px4_msgs
└── ws_cv/                   # drone_cv (camera bridge + YOLO)
```

---

## 12. Copy from an existing machine (optional)

If you already have a working tree and only need packages on the new host:

1. Install §§1–3 (apt: ROS Humble + Gazebo Harmonic + ros_gzharmonic).
2. Copy or re-clone `PX4-Autopilot` @ v1.17.0, `.venv` requirements, XRCE agent, `ws_px4`.
3. Always **rebuild PX4 on the new machine** (`make px4_sitl`) — do not copy `build/` across hosts.
4. Copy `env.sh` + `run_integration_test.sh`, fix `DRONE_ROOT` / `ROOT` paths.
5. Run the integration test.

---

## Phase B / C (camera + YOLO)

Phase B is available on this tree:

1. `.venv_cv` — Ultralytics YOLO (+ CUDA torch when available; CPU fallback).
2. `ws_cv` / `drone_cv` — Gazebo→ROS image bridge + `yolo_detect` node.
3. Daily commands: **[RUN.md](RUN.md)** § Phase B.

First build (if needed):

```bash
source /opt/ros/humble/setup.bash
cd "$DRONE_ROOT/ws_cv"
colcon build --symlink-install --packages-select drone_cv
```

Use `gz_x500_mono_cam` so a camera exists. Confirm the image in ROS before expecting detections.
