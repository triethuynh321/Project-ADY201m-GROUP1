# Agent setup — version pins (Phase A)

| Component | Version |
|-----------|---------|
| OS | Ubuntu 22.04 (Jammy) |
| ROS 2 | Humble |
| Gazebo | Harmonic 8.x (`gz-harmonic`) |
| ros_gz | `ros-humble-ros-gzharmonic` |
| PX4 | v1.17.0 |
| px4_msgs | release/1.17 |
| Micro XRCE-DDS Agent | v2.4.3 |
| RMW | rmw_fastrtps_cpp |

Workspace root: `$HOME/Workspace/260727-drone-setup` (`DRONE_ROOT`).

Full install: [SETUP.md](SETUP.md). Daily run: [RUN.md](RUN.md).
