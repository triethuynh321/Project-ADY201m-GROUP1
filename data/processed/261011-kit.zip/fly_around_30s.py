#!/usr/bin/env python3
"""Fly a ~30s square circuit in PX4 SITL, then land.

Connects over MAVLink (offboard UDP 14540 ↔ PX4 14580).
Requires PX4 SITL already running.
"""

from __future__ import annotations

import argparse
import math
import sys
import time

from pymavlink import mavutil


def connect(timeout_s: float = 15.0) -> mavutil.mavfile:
    # PX4 SITL offboard: PX4 listens on 14580, sends to 14540.
    master = mavutil.mavlink_connection(
        'udpin:0.0.0.0:14540',
        source_system=255,
        source_component=190,
    )
    print('[fly] waiting for heartbeat on udpin:14540 ...')
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        msg = master.recv_match(type='HEARTBEAT', blocking=True, timeout=1)
        if msg is not None:
            print(f'[fly] heartbeat from sys={master.target_system} comp={master.target_component}')
            return master
    raise TimeoutError('No MAVLink heartbeat (is PX4 SITL running?)')


def set_mode(master: mavutil.mavfile, mode_name: str) -> None:
    mode_map = master.mode_mapping()
    if mode_name not in mode_map:
        raise RuntimeError(f'Mode {mode_name} not in mapping: {sorted(mode_map)}')
    # PX4 mapping is (base_mode, custom_mode, custom_sub_mode)
    base_mode, custom_mode, custom_sub_mode = mode_map[mode_name]
    master.mav.command_long_send(
        master.target_system,
        master.target_component,
        mavutil.mavlink.MAV_CMD_DO_SET_MODE,
        0,
        float(base_mode),
        float(custom_mode),
        float(custom_sub_mode),
        0, 0, 0, 0,
    )
    print(f'[fly] set mode {mode_name} ({base_mode},{custom_mode},{custom_sub_mode})')


def send_gcs_heartbeat(master: mavutil.mavfile) -> None:
    master.mav.heartbeat_send(
        mavutil.mavlink.MAV_TYPE_GCS,
        mavutil.mavlink.MAV_AUTOPILOT_INVALID,
        0, 0, 0,
    )


def wait_command_ack(master: mavutil.mavfile, command: int, timeout_s: float = 3.0):
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        msg = master.recv_match(type='COMMAND_ACK', blocking=True, timeout=0.5)
        if msg and msg.command == command:
            return msg.result
        text = master.recv_match(type='STATUSTEXT', blocking=False)
        if text:
            print(f'[fly] {text.text}')
    return None


def arm(master: mavutil.mavfile, arming: bool = True) -> None:
    master.mav.command_long_send(
        master.target_system,
        master.target_component,
        mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM,
        0,
        1.0 if arming else 0.0,
        0, 0, 0, 0, 0, 0,
    )
    print('[fly] arm' if arming else '[fly] disarm')
    result = wait_command_ack(master, mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM)
    if arming and result not in (None, mavutil.mavlink.MAV_RESULT_ACCEPTED):
        print(
            f'[fly] WARN: arm rejected (result={result}). '
            'Common causes: tipped over after prop collision (Attitude failure), '
            'or system health / RC checks. Reset the drone upright in Gazebo and retry.'
        )


def takeoff(master: mavutil.mavfile, alt_m: float) -> None:
    master.mav.command_long_send(
        master.target_system,
        master.target_component,
        mavutil.mavlink.MAV_CMD_NAV_TAKEOFF,
        0,
        0, 0, 0, float('nan'),
        float('nan'), float('nan'),
        alt_m,
    )
    print(f'[fly] takeoff to {alt_m:.1f} m')


def land(master: mavutil.mavfile) -> None:
    master.mav.command_long_send(
        master.target_system,
        master.target_component,
        mavutil.mavlink.MAV_CMD_NAV_LAND,
        0,
        0, 0, 0, float('nan'),
        float('nan'), float('nan'), 0,
    )
    print('[fly] land')


def send_position(master: mavutil.mavfile, x: float, y: float, z_up: float, yaw: float) -> None:
    """NED position: x north, y east, z down (so altitude up => negative z)."""
    type_mask = (
        mavutil.mavlink.POSITION_TARGET_TYPEMASK_VX_IGNORE
        | mavutil.mavlink.POSITION_TARGET_TYPEMASK_VY_IGNORE
        | mavutil.mavlink.POSITION_TARGET_TYPEMASK_VZ_IGNORE
        | mavutil.mavlink.POSITION_TARGET_TYPEMASK_AX_IGNORE
        | mavutil.mavlink.POSITION_TARGET_TYPEMASK_AY_IGNORE
        | mavutil.mavlink.POSITION_TARGET_TYPEMASK_AZ_IGNORE
        | mavutil.mavlink.POSITION_TARGET_TYPEMASK_YAW_RATE_IGNORE
    )
    master.mav.set_position_target_local_ned_send(
        0,
        master.target_system,
        master.target_component,
        mavutil.mavlink.MAV_FRAME_LOCAL_NED,
        type_mask,
        x, y, -z_up,
        0, 0, 0,
        0, 0, 0,
        yaw, 0,
    )


def get_local_pose(master: mavutil.mavfile, timeout_s: float = 2.0):
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        msg = master.recv_match(type='LOCAL_POSITION_NED', blocking=True, timeout=0.5)
        if msg:
            return msg.x, msg.y, -msg.z  # return z as altitude up
    return None


def hold_offboard_stream(master: mavutil.mavfile, x: float, y: float, z_up: float, yaw: float, seconds: float) -> None:
    t_end = time.time() + seconds
    while time.time() < t_end:
        send_position(master, x, y, z_up, yaw)
        time.sleep(0.05)


def main() -> int:
    parser = argparse.ArgumentParser(description='PX4 SITL 30s fly-around demo')
    parser.add_argument('--duration', type=float, default=30.0, help='Cruise duration seconds (default 30)')
    parser.add_argument('--alt', type=float, default=5.0, help='Cruise altitude AGL meters')
    parser.add_argument('--radius', type=float, default=6.0, help='Square half-side / circle radius meters')
    parser.add_argument('--pattern', choices=('square', 'circle'), default='square')
    args = parser.parse_args()

    master = connect()

    # Ask for position stream + flush so mode_mapping works
    master.mav.request_data_stream_send(
        master.target_system,
        master.target_component,
        mavutil.mavlink.MAV_DATA_STREAM_ALL,
        10,
        1,
    )
    master.mav.command_long_send(
        master.target_system,
        master.target_component,
        mavutil.mavlink.MAV_CMD_SET_MESSAGE_INTERVAL,
        0,
        mavutil.mavlink.MAVLINK_MSG_ID_STATUSTEXT,
        200000,  # 5 Hz
        0, 0, 0, 0, 0,
    )
    for _ in range(40):
        send_gcs_heartbeat(master)
        master.recv_match(blocking=False)
        time.sleep(0.02)

    home = get_local_pose(master, timeout_s=5.0)
    if home is None:
        print('[fly] warn: no LOCAL_POSITION_NED yet; assuming origin')
        home = (0.0, 0.0, 0.0)
    hx, hy, hz = home
    print(f'[fly] local pose NED-up ≈ ({hx:.2f}, {hy:.2f}, {hz:.2f})')

    # Prefer OFFBOARD position circuit. Seed setpoints before engaging.
    cruise_z = max(args.alt, hz + 1.0)
    yaw0 = 0.0
    for _ in range(20):
        send_gcs_heartbeat(master)
        send_position(master, hx, hy, cruise_z, yaw0)
        time.sleep(0.05)

    set_mode(master, 'OFFBOARD')
    time.sleep(0.3)
    arm(master, True)

    # Climb
    print('[fly] climbing ...')
    climb_end = time.time() + 8.0
    last_report = 0.0
    while time.time() < climb_end:
        send_gcs_heartbeat(master)
        send_position(master, hx, hy, cruise_z, yaw0)
        text = master.recv_match(type='STATUSTEXT', blocking=False)
        if text:
            print(f'[fly] {text.text}')
        now = time.time()
        if now - last_report >= 1.0:
            pose = get_local_pose(master, timeout_s=0.5)
            if pose:
                print(f'[fly] alt={pose[2]:.2f} m (target {cruise_z:.1f} m)')
            last_report = now
        time.sleep(0.05)

    pose = get_local_pose(master, timeout_s=1.0)
    if pose is None or pose[2] < max(1.0, cruise_z * 0.4):
        print(
            '[fly] WARN: altitude did not rise.\n'
            '      Often: YOLO car/person props spawned on the drone and tipped it '
            '(Arming denied: Attitude failure).\n'
            '      Fix: stop yolo_props, remove yolo_* models, set the drone upright '
            'in Gazebo, wait ~10s for attitude to settle, then retry.\n'
            '      Or launch detect without props: ros2 launch drone_cv detect.launch.py props:=false'
        )
    else:
        print(f'[fly] climb ok, alt={pose[2]:.2f} m')

    print(f'[fly] flying {args.pattern} for {args.duration:.0f}s @ {cruise_z:.1f} m')
    t0 = time.time()
    r = args.radius
    while True:
        elapsed = time.time() - t0
        if elapsed >= args.duration:
            break
        if args.pattern == 'square':
            # 4 legs
            leg = int((elapsed / args.duration) * 4) % 4
            corners = [
                (hx + r, hy + r),
                (hx + r, hy - r),
                (hx - r, hy - r),
                (hx - r, hy + r),
            ]
            tx, ty = corners[leg]
            yaw = math.atan2(ty - hy, tx - hx)
        else:
            ang = 2.0 * math.pi * (elapsed / args.duration)
            tx = hx + r * math.cos(ang)
            ty = hy + r * math.sin(ang)
            yaw = ang + math.pi / 2.0
        send_position(master, tx, ty, cruise_z, yaw)
        time.sleep(0.05)

    print('[fly] returning / landing ...')
    hold_offboard_stream(master, hx, hy, cruise_z, yaw0, 3.0)
    set_mode(master, 'LAND')
    land(master)

    # Wait until near ground or timeout
    t_land = time.time()
    while time.time() - t_land < 25.0:
        pose = get_local_pose(master, timeout_s=1.0)
        if pose and pose[2] < 0.4:
            print('[fly] on ground')
            break
        time.sleep(0.5)

    arm(master, False)
    print('[fly] done')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print('\n[fly] interrupted')
        raise SystemExit(130)
    except Exception as exc:  # noqa: BLE001
        print(f'[fly] ERROR: {exc}', file=sys.stderr)
        raise SystemExit(1)
